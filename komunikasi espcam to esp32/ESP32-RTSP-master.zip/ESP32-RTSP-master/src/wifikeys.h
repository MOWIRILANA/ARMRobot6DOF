#include <Arduino.h>
// Change YOUR_AP_NAME and YOUR_AP_PASSWORD to your WiFi credentials
const char *ssid = "YOUR_AP_NAME";		   // Put your SSID here
const char *password = "YOUR_AP_PASSWORD"; // Put your PASSWORD here