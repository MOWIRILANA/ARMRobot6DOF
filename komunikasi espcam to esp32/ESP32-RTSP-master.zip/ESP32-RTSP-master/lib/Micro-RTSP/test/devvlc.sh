# for testing
vlc -v rtsp://192.168.86.215:8554/mjpeg/1
